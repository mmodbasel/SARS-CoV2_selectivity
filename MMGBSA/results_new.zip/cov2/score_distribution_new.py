import matplotlib.pyplot as plt
import numpy as np
import os
import matplotlib.mlab as mlab
from scipy.stats import norm
import seaborn as sns

dpi = 1200
csv_file = 'cov2_actives.csv'
protein_name = 'COV2_MM'
protocol = 'GBSA'
x_ticks = [-140,-120,-100,-80,-60,-40,-20,0]
y_ticks = [0,0.02,0.04,0.06,0.08]
#y_ticks = [0,2,4,6,8,10,12]

# accepts output from screening explorer

#execution
wd = os.getcwd() + '/'


f_o = open(csv_file,'r')
f_c = f_o.read().split('\n')
f_c = f_c[1:-1]

actives_array = []
decoys_array = []

for line in f_c:
	ls = line.split(',')
	ident = int(ls[2])
	score = ls[1]
	if ident == 1:
		actives_array.append(float(score))
	elif ident == 0:
		decoys_array.append(float(score))
	else:
		print('error, could not read data')

new_bins=np.histogram(np.hstack((actives_array,decoys_array)), bins=40)[1]
# bins are determined according to: https://stackoverflow.com/questions/23617129/matplotlib-how-to-make-two-histograms-have-the-same-bin-width


#fig1 = plt.figure(facecolor='white')
#graph1 = fig1.add_subplot(1,1,1)
#sns.distplot(actives_array, bins=new_bins, color = '#D20537', norm_hist = True)
#sns.distplot(decoys_array, bins=new_bins, color = '#006E6E', norm_hist = True)
#sns.distplot(actives_array, bins=15, color = '#D20537', norm_hist = False)
sns.distplot(decoys_array, bins=15, color = '#006E6E', norm_hist = False)
#graph1.hist(actives_array, color = '#D20537', edgecolor='black', linewidth=1.2)
#graph1.hist(actives_array, color = '#D20537', edgecolor='black', linewidth=1.0, bins=new_bins)
#graph1.hist(decoys_array, color = '#006E6E', edgecolor='black', linewidth=1.0, bins=new_bins)

#graph1.hist(decoys_array, color = '#006E6E', edgecolor='black', linewidth=1.2)
plt.xticks(x_ticks)
plt.yticks(y_ticks)
plt.xlim(min(x_ticks),max(x_ticks))
plt.ylim(min(y_ticks),max(y_ticks))
plt.title(protein_name + '_' + protocol)
plt.xlabel('Free energy (kcal/mol)')
plt.ylabel('Number of compounds')
#plt.show()
plt.savefig(wd + protein_name + '_' + protocol + '.png',dpi=dpi)

